# -*- coding: utf-8 -*-
"""
Created on Mon Sep 23 22:38:42 2019

@author: KJH
"""

import pandas as pd
import csv
import collections

data = pd.read_csv("test_younggil.csv", sep='|', dtype = 'unicode', names = ['no','time','protocol','text description','srcip','dstip','total pkt length','L4 payload hexdump'])#'no','time','highest protocol(L4 protocol)','text description','srcipaddress:srcport','dst ip address:dst port','total pkt length','L4 payload hexdump')
counter_smae_src = collections.Counter(data["dstip"])
counter_smae_src_list = [(k,counter_smae_src[k]) for k in counter_smae_src]
pd.DataFrame(counter_smae_src_list, columns=['dst_IP_Port','count'])
df_dstIP_Port = pd.DataFrame(counter_smae_src_list, columns=['dstIP','count'])
print("#####################같은목적지인데 같은 포트인 애들 개수###################")
print(df_dstIP_Port)
"""목적지 IP와 Port 나누는 코드"""
split = data.dstip.str.split(':')
split = split.apply(lambda x: pd.Series(x))
split.columns = ["dstIP","dport"]
counter_IP=collections.Counter(split["dstIP"]) #같은 목적지 ip 개수
counter_IP_list = [(k,counter_IP[k]) for k in counter_IP]
pd.DataFrame(counter_IP_list, columns=['dst_IP','Dst_host_count'])
df_dstIP = pd.DataFrame(counter_IP_list, columns=['dstIP','같은 dst_IP개수'])
result = pd.merge(split, df_dstIP, on = "dstIP" )
print("##################같은 목적지ip 개수###################")
print(result)
